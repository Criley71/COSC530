### Compile
use make command:

`make`

### run
use: `make run` 

to run the program it expects a `config.txt` file in the same directory as main.cpp and using `make run` it will use `trace.dat` as stdin 